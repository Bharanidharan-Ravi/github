import React, { useRef, useState } from "react";
import { useTicketStore } from "../../TicketStore/TicketStore";
import { postImage, RemoveImage } from 'shared-store';
import "./CommentBar.css";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";


const MAX_FILES = 10;
const MAX_FILE_SIZE = 10 * 1024 * 1024;

const Allowed_TYPES = [
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/jpg",
  "application/pdf",
  "application/msword", // docx
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // docx
  "application/vnd.ms-excel", // Excel 97-2003
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // Excel xlsx
];

function CommentBar({ labels = [] }) {
  const { addImages, AttachImages, removeImage,
    handleInputChange, formData } = useTicketStore();
  const [dragging, setDragging] = useState(false);
  const [showMentionMenu, setShowMentionMenu] = useState(false);
  const [showLabelMenu, setShowLabelMenu] = useState(false);
  const [draggingOuter, setDraggingOuter] = useState(false);
  const [inlineDragging, setInlineDragging] = useState(false);
  const [dropLineTop, setdropLineTop] = useState(false);
  const [ghostImageUrl, setGhostImageUrl] = useState(null);
  const [ghostPos, setGhostPos] = useState({ x: 0, y: 0 });
  // const [submitting, setSubmitting] = useState(false);

  const quillRef = useRef(null);

  // Quill toolbar modules
  const modules = {
    toolbar: {
      container: [
        ["bold", "italic", "underline"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["clean"],
      ],
    },
    clipboard: {
      matchers: [
        [
          "img",
          () => {
            // Block pasted inline base64 images completely
            return { ops: [] };
          },
        ],
      ],
    },
  };
  console.log("formData :", formData);

  const handleEditorChange = (html) => {
    handleInputChange("description", html);
  };

  // ========= helpers =========

  const handleMentionClick = () => {
    setShowLabelMenu(false);
    setShowMentionMenu((s) => !s);
  };

  const handleLabelClick = () => {
    setShowMentionMenu(false);
    setShowLabelMenu((s) => !s);
  }

  const insertAtCursor = (html) => {
    const editor = quillRef.current.getEditor();
    quillRef.insertText(0, "hello");
    console.log("quillRef :", quillRef);

    const range = editor.getSelection(true);
    editor.insertEmbed(range.index, "text", "");
    editor.clipboard.dangerouslyPasteHTML(range.index, html);
    editor.setSelection(range.index + html.length);
  };

  // ========= toolbar actions =========
  const handleSelectUser = (user) => {
    const display = user.displayName || user.name || user.username || "";
    if (!display) return;
    insertAtCursor(`<strong>@${display}</strong>`);
    setShowMentionMenu(false);
  };

  const handleSelectLabel = (label) => {
    if (!label?.label_TITLE) return;
    insertAtCursor(`<span style="background:#fef3c7">@${label.label_TITLE}</span> `);
    setShowLabelMenu(false);
  };

  // Helper: insert HTML/image into Quill at cursor
  const insertImageintoQuill = (url) => {
    const editor = quillRef.current.getEditor();
    // const range = editor.getSelection(true);
    const range = editor.getSelection(true) || {
      index: editor.getLength(),
      length: 0,
    };
    editor.insertEmbed(range.index, "image", url, "user");
    editor.setSelection(range.index + 1, 0);
  }

  // ---------------- IMAGE UPLOAD LOGIC ----------------

  const uploadFile = async (file) => {
    const res = await postImage(file);
    return {
      url: res.publicUrl,
      name: res.fileName,
      localPath: res.localPath,
      type: file.type,
    };
  };

  const handleDelete = async (img) => {
    try {
      await removeImage(img);
    } catch (err) {
      console.error(err);
      alert("Failed to delete file.");
    }
  };

  // const processFiles = async (files) => {
  //   if (AttachImages.length >= MAX_FILES) {
  //     alert(`Limit reached. Max ${MAX_FILES} attachments.`);
  //     return;
  //   }

  //   const validFiles = [];

  //   for (const file of files) {
  //     if (!Allowed_TYPES.includes(file.type)) {
  //       alert("Invalid file type.");
  //       continue;
  //     }
  //     if (file.size > MAX_FILE_SIZE) {
  //       alert("File too large (max 10MB).");
  //       continue;
  //     }
  //     const isDuplicate = AttachImages.some((img) => img.name === file.name);
  //     if (isDuplicate) {
  //       alert("This file is already added.");
  //       continue;
  //     }
  //     validFiles.push(file);
  //   }

  //   for (const file of validFiles) {
  //     try {
  //       const uploaded = await uploadFile(file);
  //       console.log("uploaded :", uploaded);

  //       addImages(uploaded);
  //     } catch (err) {
  //       console.error(err);
  //       alert("Error uploading file: " + err.message);
  //     }
  //   }
  // };

  // ========= drag/drop handlers =========
  const handleAttachmentUpload = useCallback(
    async (files) => {
      if (AttachImages.length >= MAX_FILES) {
        alert(`Limit reached. Max ${MAX_FILES} attachments.`);
        return;
      }

      const validFiles = [];

      for (const file of files) {
        if (!Allowed_TYPES.includes(file.type)) {
          alert("Invalid file type.");
          continue;
        }
        if (file.size > MAX_FILE_SIZE) {
          alert("File too large (max 10MB).");
          continue;
        }
        const isDuplicate = AttachImages.some((img) => img.name === file.name);
        if (isDuplicate) {
          alert("This file is already added.");
          continue;
        }
        validFiles.push(file);
      }
      for (const file of validFiles) {
        try {
          const uploaded = await uploadFile(file);
          console.log("uploaded :", uploaded);

          addImages(uploaded);
        } catch (err) {
          console.error(err);
          alert("Error uploading file: " + err.message);
        }
      }
    },);

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragging(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    setDragging(false);

    const files = Array.from(e.dataTransfer.files);
    // const droppedText = e.dataTransfer.getData("text/plain");

    if (files.length > 0) {
      await processFiles(files);
      return;
    }
    if (droppedText) {
      insertAtCursor(`<p>${droppedText}</p>`);
    }
  };


  // ========= history storing: onBlur store full text block =========

  //   const handleBlur = () => {
  //     const text = (formData.description || "").trim();
  //     if (!text) return;
  //     addCommentHistory(text); // stores full multi-line block
  //   };

  return (
    <div
      className={`commentbar-container animated ${dragging ? "dragging" : ""
        }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Toolbar */}
      <div className="commentbar-toolbar">
        {/* <button
          type="button"
          className="cb-btn"
          onClick={handleBold}
          title="Bold (**text**)"
        >
          B
        </button>
        <button
          type="button"
          className="cb-btn"
          onClick={handleItalic}
          title="Italic (*text*)"
        >
          I
        </button> */}

        <div className="cb-divider" />

        <button
          type="button"
          className="cb-btn"
          onClick={handleMentionClick}
          title="Mention user"
        >
          @
        </button>
        <button
          type="button"
          className="cb-btn"
          onClick={handleLabelClick}
          title="Insert label"
        >
          #
        </button>

        {/* <div className="cb-divider" />

        <button
          type="button"
          className="cb-btn cb-history"
          onClick={handleHistoryClick}
          title="Insert previous text"
        >
          ⏱
        </button> */}
      </div>

      {/* Menus under toolbar */}
      {showMentionMenu && userList.length > 0 && (
        <div className="cb-menu">
          {userList.map((u) => (
            <div
              key={u.id || u.username || u.name}
              className="cb-menu-item"
              onClick={() => handleSelectUser(u)}
            >
              @{u.displayName || u.name || u.username}
            </div>
          ))}
        </div>
      )}

      {showLabelMenu && labels.length > 0 && (
        <div className="cb-menu">
          {labels.map((l) => (
            <div
              key={l.label_Id || l.label_TITLE}
              className="cb-menu-item"
              onClick={() => handleSelectLabel(l)}
            >
              #{l.label_TITLE}
            </div>
          ))}
        </div>
      )}

      <ReactQuill
        ref={quillRef}
        theme="snow"
        value={formData.description}
        onChange={handleEditorChange}
        modules={modules}
        style={{
          marginBottom: 10,
          minHeight: 150
        }}
      />

      {/* Attachments preview */}
      {AttachImages.length > 0 && (
        <div className="commentbar-preview">
          {AttachImages.map((img, i) => (
            <div key={i} className="commentbar-thumb">
              <img src={img.url} alt="" />
              <button
                type="button"
                className="commentbar-delete"
                onClick={(e) => {
                  e.preventDefault();
                  handleDelete(img);
                }}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Text area */}
      <textarea
        ref={quillRef}
        className="commentbar-textarea"
        rows="5"
        value={formData.description}
        placeholder="Write a comment… You can drag text or files here."
        onChange={(e) => handleInputChange("description", e.target.value)}
      // onBlur={handleBlur}
      />

      {/* Drag placeholder */}
      {!AttachImages.length && !formData.description && dragging && (
        <div className="commentbar-drag-overlay">
          Drop images, documents, or text here
        </div>
      )}
    </div>
  );
}

export default CommentBar;